#pragma once

template<typename Type, unsigned long Tag>
class Pointer final
{

};