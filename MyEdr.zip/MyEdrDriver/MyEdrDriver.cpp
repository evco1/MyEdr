#include <fltKernel.h>

#include "Queue.h"
#include "Result.h"
#include "AutoDeletedPointer.h"
#include "Statuses.h"
#include "Debug.h"
#include "MyEdrEvent.h"

#include <wdm.h>

const UINT32 CONTEXT_POOL_TAG = 'chem';
const size_t MAX_EVENT_QUEUE_ENTRY_COUNT = 10000;

struct MyEdrData final
{
    PDRIVER_OBJECT DriverObject;
    AutoDeletedPointer<_FLT_FILTER> Filter;
    Queue<AutoDeletedPointer<MyEdrEvent>> EventQueue;
};

MyEdrData* g_myEdrData{ nullptr };

FLT_POSTOP_CALLBACK_STATUS HandleFilterCallback(
    MyEdrEventId eventId,
    PFLT_CALLBACK_DATA data
)
{
    RETURN_ON_BAD_STATUS(data->IoStatus.Status, FLT_POSTOP_FINISHED_PROCESSING);
    RETURN_ON_CONDITION(STATUS_REPARSE == data->IoStatus.Status, FLT_POSTOP_FINISHED_PROCESSING);

    AutoDeletedPointer<FLT_FILE_NAME_INFORMATION> nameInfo{ nullptr, FltReleaseFileNameInformation };

    RETURN_ON_BAD_STATUS(
        FltGetFileNameInformation(
            data,
            FLT_FILE_NAME_NORMALIZED | FLT_FILE_NAME_QUERY_DEFAULT,
            &nameInfo.get()
        ),
        FLT_POSTOP_FINISHED_PROCESSING
    );

    AutoDeletedPointer<MyEdrEvent> event;
    
    event.allocate();
    event->Id = eventId;
    event->ProcessId = FltGetRequestorProcessId(data);
    KeQuerySystemTime(&event->TimeStamp);
    UNICODE_STRING temp{ 0, sizeof(event->Name) - sizeof(WCHAR), event->Name };
    RtlCopyUnicodeString(&temp, &nameInfo->Name);
    event->Name[temp.Length / sizeof(WCHAR)] = '\0';

    if (g_myEdrData->EventQueue.isFull())
    {
        g_myEdrData->EventQueue.popHead();
    }

    DEBUG_PRINT("%u, %u, %llu, %wZ", event->Id, event->ProcessId, event->TimeStamp, temp);

    DEBUG_PRINT("%d", g_myEdrData->EventQueue.pushTail(move(event)).getStatus());

    return FLT_POSTOP_FINISHED_PROCESSING;
}

FLT_POSTOP_CALLBACK_STATUS MyEdrPostCreate(
    PFLT_CALLBACK_DATA Data,
    PCFLT_RELATED_OBJECTS FltObjects,
    PVOID CompletionContext,
    FLT_POST_OPERATION_FLAGS Flags
)
{
    UNREFERENCED_PARAMETER(FltObjects);
    UNREFERENCED_PARAMETER(CompletionContext);
    UNREFERENCED_PARAMETER(Flags);

    return HandleFilterCallback(FileCreate, Data);
}

FLT_POSTOP_CALLBACK_STATUS MyEdrPostWrite(
    PFLT_CALLBACK_DATA Data,
    PCFLT_RELATED_OBJECTS FltObjects,
    PVOID CompletionContext,
    FLT_POST_OPERATION_FLAGS Flags
)
{
    UNREFERENCED_PARAMETER(FltObjects);
    UNREFERENCED_PARAMETER(CompletionContext);
    UNREFERENCED_PARAMETER(Flags);

    return HandleFilterCallback(FileWrite, Data);
}

void DriverUnload(
    DRIVER_OBJECT * DriverObject
)
{
    UNREFERENCED_PARAMETER(DriverObject);

    delete g_myEdrData;
}

extern "C" NTSTATUS DriverEntry(
    PDRIVER_OBJECT DriverObject,
    PUNICODE_STRING RegistryPath
)
{
    UNREFERENCED_PARAMETER(DriverObject);
    UNREFERENCED_PARAMETER(RegistryPath);

    AutoDeletedPointer<MyEdrData> myEdrData{ new MyEdrData{
        nullptr,
        { nullptr, FltUnregisterFilter },
        { MAX_EVENT_QUEUE_ENTRY_COUNT }
    } };

    if (nullptr == myEdrData.get())
    {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    const FLT_OPERATION_REGISTRATION FilterOperationRegistration[] = \
    {
        { IRP_MJ_CREATE, 0, nullptr, MyEdrPostCreate },
        { IRP_MJ_WRITE, 0, nullptr, MyEdrPostWrite },
        { IRP_MJ_OPERATION_END }
    };

    const FLT_CONTEXT_REGISTRATION FilterContextRegistration[] = {
        { FLT_STREAMHANDLE_CONTEXT,
          0,
          nullptr,
          0,
          CONTEXT_POOL_TAG },
        { FLT_CONTEXT_END }
    };

    const FLT_REGISTRATION FilterRegistration = {
        sizeof(FLT_REGISTRATION),
        FLT_REGISTRATION_VERSION,
        0,
        FilterContextRegistration,
        FilterOperationRegistration
    };

    RETURN_STATUS_ON_BAD_STATUS(FltRegisterFilter(
        DriverObject,
        &FilterRegistration,
        &myEdrData->Filter.get()
    ));

    RETURN_STATUS_ON_BAD_STATUS(FltStartFiltering(myEdrData->Filter.get()));

    g_myEdrData = myEdrData.release();
    DriverObject->DriverUnload = DriverUnload;
    return STATUS_SUCCESS;
}
