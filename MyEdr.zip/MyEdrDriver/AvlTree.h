#pragma once

#include "AutoDeletedPointer.h"
#include "Result.h"
#include "move.h"
#include "Statuses.h"
#include "Debug.h"

#include <ntddk.h>

template<typename DataType>
class AvlTree final
{
public:
	AvlTree();
	AvlTree(const AvlTree&) = delete;
	AvlTree(AvlTree&&);

	~AvlTree();

	AvlTree& operator=(const AvlTree&) = delete;
	AvlTree& operator=(AvlTree&&);

private:
	PRTL_AVL_TABLE m_avlTable;
};

template<typename DataType>
AvlTree<DataType>::AvlTree()
{
	RtlInitializeGenericTableAvl(&m_avlTable, );
}
